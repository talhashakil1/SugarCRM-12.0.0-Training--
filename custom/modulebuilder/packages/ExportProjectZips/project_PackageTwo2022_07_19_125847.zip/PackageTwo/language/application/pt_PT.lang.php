<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['abcde_mycustommodule_type_dom']['Administration'] = 'Administration';
$app_list_strings['abcde_mycustommodule_type_dom']['Product'] = 'Produto';
$app_list_strings['abcde_mycustommodule_type_dom']['User'] = 'Utilizador';
$app_list_strings['abcde_mycustommodule_status_dom']['New'] = 'Novo';
$app_list_strings['abcde_mycustommodule_status_dom']['Assigned'] = 'Atribuída';
$app_list_strings['abcde_mycustommodule_status_dom']['Closed'] = 'Fechado';
$app_list_strings['abcde_mycustommodule_status_dom']['Pending Input'] = 'A Aguardar Resposta';
$app_list_strings['abcde_mycustommodule_status_dom']['Rejected'] = 'Rejeitado';
$app_list_strings['abcde_mycustommodule_status_dom']['Duplicate'] = 'Duplicar';
$app_list_strings['abcde_mycustommodule_priority_dom']['P1'] = 'Alto';
$app_list_strings['abcde_mycustommodule_priority_dom']['P2'] = 'Média';
$app_list_strings['abcde_mycustommodule_priority_dom']['P3'] = 'Baixo';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Accepted'] = 'Aceite';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Duplicate'] = 'Duplicar';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Closed'] = 'Fechado';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Out of Date'] = 'Obsoleto';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Invalid'] = 'Inválido';
$app_list_strings['abcde_mycustommodule_resolution_dom'][''] = '';
$app_list_strings['moduleList']['abcde_MyCustomModule'] = 'MyCustomModules';
$app_list_strings['moduleListSingular']['abcde_MyCustomModule'] = 'MyCustomModule';
