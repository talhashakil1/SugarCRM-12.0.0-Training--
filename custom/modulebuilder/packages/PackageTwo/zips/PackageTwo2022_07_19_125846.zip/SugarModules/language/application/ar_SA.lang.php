<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['abcde_mycustommodule_type_dom']['Administration'] = 'Administration';
$app_list_strings['abcde_mycustommodule_type_dom']['Product'] = 'المنتج';
$app_list_strings['abcde_mycustommodule_type_dom']['User'] = 'المستخدم';
$app_list_strings['abcde_mycustommodule_status_dom']['New'] = 'جديد';
$app_list_strings['abcde_mycustommodule_status_dom']['Assigned'] = 'معيَّن';
$app_list_strings['abcde_mycustommodule_status_dom']['Closed'] = 'مغلق';
$app_list_strings['abcde_mycustommodule_status_dom']['Pending Input'] = 'إدخال معلق';
$app_list_strings['abcde_mycustommodule_status_dom']['Rejected'] = 'مرفوض';
$app_list_strings['abcde_mycustommodule_status_dom']['Duplicate'] = 'تكرار';
$app_list_strings['abcde_mycustommodule_priority_dom']['P1'] = 'عالية';
$app_list_strings['abcde_mycustommodule_priority_dom']['P2'] = 'متوسط';
$app_list_strings['abcde_mycustommodule_priority_dom']['P3'] = 'منخفض';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Accepted'] = 'مقبول';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Duplicate'] = 'تكرار';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Closed'] = 'مغلق';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Out of Date'] = 'قديم';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Invalid'] = 'غير صالح';
$app_list_strings['abcde_mycustommodule_resolution_dom'][''] = '';
$app_list_strings['moduleList']['abcde_MyCustomModule'] = 'MyCustomModules';
$app_list_strings['moduleListSingular']['abcde_MyCustomModule'] = 'MyCustomModule';
