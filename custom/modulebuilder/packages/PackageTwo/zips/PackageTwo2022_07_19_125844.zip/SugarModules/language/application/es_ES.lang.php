<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['abcde_mycustommodule_type_dom']['Administration'] = 'Administration';
$app_list_strings['abcde_mycustommodule_type_dom']['Product'] = 'Producto';
$app_list_strings['abcde_mycustommodule_type_dom']['User'] = 'Usuario';
$app_list_strings['abcde_mycustommodule_status_dom']['New'] = 'Nuevo';
$app_list_strings['abcde_mycustommodule_status_dom']['Assigned'] = 'Asignado';
$app_list_strings['abcde_mycustommodule_status_dom']['Closed'] = 'Cerrado';
$app_list_strings['abcde_mycustommodule_status_dom']['Pending Input'] = 'Pendiente de Información';
$app_list_strings['abcde_mycustommodule_status_dom']['Rejected'] = 'Rechazado';
$app_list_strings['abcde_mycustommodule_status_dom']['Duplicate'] = 'Duplicar';
$app_list_strings['abcde_mycustommodule_priority_dom']['P1'] = 'Alta';
$app_list_strings['abcde_mycustommodule_priority_dom']['P2'] = 'Media';
$app_list_strings['abcde_mycustommodule_priority_dom']['P3'] = 'Baja';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Accepted'] = 'Aceptado';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Duplicate'] = 'Duplicar';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Closed'] = 'Cerrado';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Out of Date'] = 'Caducado';
$app_list_strings['abcde_mycustommodule_resolution_dom']['Invalid'] = 'Invalido';
$app_list_strings['abcde_mycustommodule_resolution_dom'][''] = '';
$app_list_strings['moduleList']['abcde_MyCustomModule'] = 'MyCustomModules';
$app_list_strings['moduleListSingular']['abcde_MyCustomModule'] = 'MyCustomModule';
