<?php
// created: 2022-07-19 12:14:45
$viewdefs['Talha_MediaTracking']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_EMAILS_SUBPANEL_TITLE',
  'context' => 
  array (
    'link' => 'talha_mediatracking_activities_emails',
  ),
);

$viewdefs['Talha_MediaTracking']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_EMAILS_SUBPANEL_TITLE',
  'context' => 
  array (
    'link' => 'talha_mediatracking_activities_emails',
  ),
);

$viewdefs['Talha_MediaTracking']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_EMAILS_SUBPANEL_TITLE',
  'context' => 
  array (
    'link' => 'talha_mediatracking_activities_emails',
  ),
);