<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_TALHA_MEDIATRACKING_CONTACTS_FROM_TALHA_MEDIATRACKING_TITLE'] = 'Media Trackings and Contacts Relationship';
$mod_strings['LBL_TALHA_MEDIATRACKING_CONTACTS_FROM_CONTACTS_TITLE'] = 'Media Trackings and Contacts Relationship';
