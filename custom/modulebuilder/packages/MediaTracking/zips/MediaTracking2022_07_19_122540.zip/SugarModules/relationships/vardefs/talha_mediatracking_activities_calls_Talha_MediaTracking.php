<?php
// created: 2022-07-19 12:25:40
$dictionary["Talha_MediaTracking"]["fields"]["talha_mediatracking_activities_calls"] = array (
  'name' => 'talha_mediatracking_activities_calls',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
