<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$app_list_strings['record_type_display']['Talha_MediaTracking'] = 'Media Trackings';
$app_list_strings['parent_type_display']['Talha_MediaTracking'] = 'Media Trackings';
$app_list_strings['record_type_display_notes']['Talha_MediaTracking'] = 'Media Trackings';
