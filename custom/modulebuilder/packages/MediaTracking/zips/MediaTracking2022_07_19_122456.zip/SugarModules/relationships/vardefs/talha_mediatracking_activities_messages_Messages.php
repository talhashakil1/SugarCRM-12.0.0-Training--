<?php
// created: 2022-07-19 12:24:56
$dictionary["Message"]["fields"]["talha_mediatracking_activities_messages"] = array (
  'name' => 'talha_mediatracking_activities_messages',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_messages',
  'source' => 'non-db',
  'module' => 'Talha_MediaTracking',
  'bean_name' => false,
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_MESSAGES_FROM_TALHA_MEDIATRACKING_TITLE',
);
