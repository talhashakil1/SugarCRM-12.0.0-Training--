<?php
// created: 2022-07-19 12:24:56
$dictionary["Talha_MediaTracking"]["fields"]["talha_mediatracking_activities_messages"] = array (
  'name' => 'talha_mediatracking_activities_messages',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_messages',
  'source' => 'non-db',
  'module' => 'Messages',
  'bean_name' => 'Message',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_MESSAGES_FROM_MESSAGES_TITLE',
);
