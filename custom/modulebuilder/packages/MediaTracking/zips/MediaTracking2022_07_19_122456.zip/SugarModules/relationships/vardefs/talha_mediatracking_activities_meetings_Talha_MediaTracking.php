<?php
// created: 2022-07-19 12:24:56
$dictionary["Talha_MediaTracking"]["fields"]["talha_mediatracking_activities_meetings"] = array (
  'name' => 'talha_mediatracking_activities_meetings',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
