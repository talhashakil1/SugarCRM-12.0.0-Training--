<?php
// created: 2022-07-19 12:14:45
$viewdefs['Talha_MediaTracking']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
  'context' => 
  array (
    'link' => 'talha_mediatracking_activities_notes',
  ),
);