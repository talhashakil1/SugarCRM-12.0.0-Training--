<?php
 // created: 2022-07-19 12:14:45
$layout_defs["Talha_MediaTracking"]["subpanel_setup"]['talha_mediatracking_activities_tasks'] = array (
  'order' => 100,
  'module' => 'Tasks',
  'subpanel_name' => 'Default',
  'title_key' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
  'get_subpanel_data' => 'talha_mediatracking_activities_tasks',
);
