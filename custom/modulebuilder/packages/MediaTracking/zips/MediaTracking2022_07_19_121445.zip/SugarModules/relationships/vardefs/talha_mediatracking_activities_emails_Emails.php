<?php
// created: 2022-07-19 12:14:45
$dictionary["Email"]["fields"]["talha_mediatracking_activities_emails"] = array (
  'name' => 'talha_mediatracking_activities_emails',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_emails',
  'source' => 'non-db',
  'module' => 'Talha_MediaTracking',
  'bean_name' => false,
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_EMAILS_FROM_TALHA_MEDIATRACKING_TITLE',
);
