<?php
 // created: 2022-07-19 12:14:45
$layout_defs["Talha_MediaTracking"]["subpanel_setup"]['talha_mediatracking_activities_emails'] = array (
  'order' => 100,
  'module' => 'Emails',
  'subpanel_name' => 'Default',
  'title_key' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
  'get_subpanel_data' => 'talha_mediatracking_activities_emails',
);
