<?php
 // created: 2022-07-19 12:14:45
$layout_defs["Talha_MediaTracking"]["subpanel_setup"]['talha_mediatracking_contacts'] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_TALHA_MEDIATRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'talha_mediatracking_contacts',
);
