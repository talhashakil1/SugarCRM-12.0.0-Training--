<?php
// created: 2022-07-19 12:14:45
$dictionary["Talha_MediaTracking"]["fields"]["talha_mediatracking_activities_emails"] = array (
  'name' => 'talha_mediatracking_activities_emails',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
