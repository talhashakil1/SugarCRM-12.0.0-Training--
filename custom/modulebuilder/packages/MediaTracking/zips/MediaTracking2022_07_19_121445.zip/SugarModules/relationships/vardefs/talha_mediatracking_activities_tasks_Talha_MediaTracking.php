<?php
// created: 2022-07-19 12:14:45
$dictionary["Talha_MediaTracking"]["fields"]["talha_mediatracking_activities_tasks"] = array (
  'name' => 'talha_mediatracking_activities_tasks',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
