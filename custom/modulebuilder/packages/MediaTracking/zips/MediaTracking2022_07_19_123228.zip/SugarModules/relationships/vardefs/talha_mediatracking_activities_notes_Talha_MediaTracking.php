<?php
// created: 2022-07-19 12:32:28
$dictionary["Talha_MediaTracking"]["fields"]["talha_mediatracking_activities_notes"] = array (
  'name' => 'talha_mediatracking_activities_notes',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
