<?php
 // created: 2022-07-19 12:32:28
$layout_defs["Talha_MediaTracking"]["subpanel_setup"]['talha_mediatracking_activities_calls'] = array (
  'order' => 100,
  'module' => 'Calls',
  'subpanel_name' => 'Default',
  'title_key' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
  'get_subpanel_data' => 'talha_mediatracking_activities_calls',
);
