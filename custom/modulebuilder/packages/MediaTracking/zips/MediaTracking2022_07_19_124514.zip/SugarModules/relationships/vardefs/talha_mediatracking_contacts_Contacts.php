<?php
// created: 2022-07-19 12:45:14
$dictionary["Contact"]["fields"]["talha_mediatracking_contacts"] = array (
  'name' => 'talha_mediatracking_contacts',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_contacts',
  'source' => 'non-db',
  'module' => 'Talha_MediaTracking',
  'bean_name' => false,
  'vname' => 'LBL_TALHA_MEDIATRACKING_CONTACTS_FROM_TALHA_MEDIATRACKING_TITLE',
  'id_name' => 'talha_mediatracking_contactstalha_mediatracking_ida',
);
