<?php
 // created: 2022-07-19 12:45:14
$layout_defs["Talha_MediaTracking"]["subpanel_setup"]['talha_mediatracking_activities_messages'] = array (
  'order' => 100,
  'module' => 'Messages',
  'subpanel_name' => 'Default',
  'title_key' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_MESSAGES_FROM_MESSAGES_TITLE',
  'get_subpanel_data' => 'talha_mediatracking_activities_messages',
);
