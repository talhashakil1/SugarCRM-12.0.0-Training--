<?php
// created: 2022-07-19 12:45:14
$dictionary["Talha_MediaTracking"]["fields"]["talha_mediatracking_contacts"] = array (
  'name' => 'talha_mediatracking_contacts',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_TALHA_MEDIATRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'talha_mediatracking_contactscontacts_idb',
);
