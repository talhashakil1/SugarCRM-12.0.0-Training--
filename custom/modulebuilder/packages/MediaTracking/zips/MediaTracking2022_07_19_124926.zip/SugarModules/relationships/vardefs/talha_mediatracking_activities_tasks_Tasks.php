<?php
// created: 2022-07-19 12:49:26
$dictionary["Task"]["fields"]["talha_mediatracking_activities_tasks"] = array (
  'name' => 'talha_mediatracking_activities_tasks',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_tasks',
  'source' => 'non-db',
  'module' => 'Talha_MediaTracking',
  'bean_name' => 'Talha_MediaTracking',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_TASKS_FROM_TALHA_MEDIATRACKING_TITLE',
);
