<?php
// created: 2022-07-19 12:49:26
$dictionary["Message"]["fields"]["talha_mediatracking_activities_messages"] = array (
  'name' => 'talha_mediatracking_activities_messages',
  'type' => 'link',
  'relationship' => 'talha_mediatracking_activities_messages',
  'source' => 'non-db',
  'module' => 'Talha_MediaTracking',
  'bean_name' => 'Talha_MediaTracking',
  'vname' => 'LBL_TALHA_MEDIATRACKING_ACTIVITIES_MESSAGES_FROM_TALHA_MEDIATRACKING_TITLE',
);
