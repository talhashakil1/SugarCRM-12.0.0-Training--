<?php

$mod_strings['LBL_CHANGE_DESCRIPTION_JOB'] = 'Change Description Job';