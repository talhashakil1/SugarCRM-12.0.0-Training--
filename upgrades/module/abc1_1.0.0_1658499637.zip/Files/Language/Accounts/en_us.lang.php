<?php


$mod_strings['LBL_VEHICLE_NUMBER'] = 'Vehicle Number';